console.log("------------TASK1------------")
const printArray = arr => console.log(arr) ;
// printArray([1, 2, 3, 4, 5]);


// const printArray2 = arr => {
//     for (let i = 0; i < arr.length; i++) {
//         console.log(arr[i]);
//     }
// }
// printArray2([1, 2, 3, 4, 5]);


// printArray.forEach(a => console.log(a));

console.log("------------TASK2------------")
const reverseArray = arr => arr.reverse();
// console.log(reverseArray([1, 2, 3, 4, 5]));


// const reverseArray2 = arr => {
//     let temp;
//     for (let i = 0, j = arr.length - 1; i < j; i++, j--){
//         temp = arr[i];
//         arr[i] = arr[j];
//         arr[j] = temp;
//     }
//     console.log("Вариант 2 --- " + arr)
//     return arr;
// }
// reverseArray2([1, 2, 3, 4, 5]);
console.log("------------TASK3------------")

const search = (arr,value) => arr.includes(value) ? arr.indexOf(value) : -1;
search([1,2,3,4,5,6,7,8], 5)



// const search2 = (arr, value) => {
//     let index = arr.indexOf(value);
//     if (arr.includes(value)) {
//         console.log("Index of " + value + " = " + index);
//         return index;
//     } else {
//         return -1;
//     }
// }
//
// search2([1,2,3,4,5,6,7,8], 3)
console.log("------------TEST1------------")

const primes = [2, 3, 5, 7, 11, 13, 17, 19];
printArray(primes); // 2, 3, 5, 7, 11, 13, 17, 19

console.log("------------TEST2------------")

reverseArray(primes);
printArray(primes); // 19, 17, 13, 11, 7, 5, 3, 2

console.log("------------TEST3------------")

let index = search(primes, 13);
console.log(index); // 2

console.log("------------TEST4------------")

index = search(primes, 10);
console.log(index); // -1

// function print(arr) {
//     console.log(arr[0],arr[1],arr[2],arr[3],arr[4],arr[5],arr[6],arr[7],arr[8]);
// }
// print([1,2,3,4,5,6,7,8,9]);




console.log("  -----------TEST-----------  ")
console.log("-  ----------TEST----------  -")
console.log("--  ---------TEST---------  --")
console.log("---  --------TEST--------  ---")
console.log("----  -------TEST-------  ----")
console.log("-----  ------TEST------  -----")
console.log("------  -----TEST-----  ------")
console.log("-------  ----TEST----  -------")
console.log("--------  ---TEST---  --------")
console.log("---------  --TEST--  ---------")
console.log("----------  -TEST-  ----------")
console.log("-----------  TEST  -----------")
console.log("  -----------TEST-----------  ")
console.log("-  ----------TEST----------  -")
console.log("--  ---------TEST---------  --")
console.log("---  --------TEST--------  ---")
console.log("----  -------TEST-------  ----")
console.log("-----  ------TEST------  -----")
console.log("------  -----TEST-----  ------")
console.log("-------  ----TEST----  -------")
console.log("--------  ---TEST---  --------")
console.log("---------  --TEST--  ---------")
console.log("----------  -TEST-  ----------")
console.log("-----------  TEST  -----------")


const nums = [1, 2, 3, 4, 5];
const doubled = nums.map(a => a * 2)
console.log(doubled)

const nums2 = [1, 2, 3, 4, 5, 6, 7, 8, 9];
const evens = nums2.filter(a => a % 2 === 0);
console.log(evens)

const fruits = ["apple", "banana", "cherry"];
fruits.forEach(fruit => {
    console.log("Fruit: " + fruit);
})


const checkEvenOdd = num => num % 2 === 0 ? "even" : "odd";
console.log(checkEvenOdd(6));
console.log(checkEvenOdd(8));


const max = (a,b) => a > b ? a : b;
console.log(max(5, 10));
console.log(max(12, 3));

const markSigns = arr => arr.map(a => a > 0 ? "positive" : "negative");
console.log(markSigns([3, -1, 0, 5, -8]));

const filterStrings = arr => arr.filter(a => typeof a === "string");
console.log(filterStrings([1, "hi", true, "hello", 5]));


const filterPositiveEven = arr => arr.filter(a => a > 0  && a % 2 === 0);
console.log(filterPositiveEven([1, 2, -3, 4, -6, 0, 10]));


const isPalindrome = str => str === str.split("").reverse().join("");
console.log(isPalindrome("racecar"));
console.log(isPalindrome("hello"));


const checkAge = age => age >= 18 ? "adult" : "minor"
console.log(checkAge(20));
console.log(checkAge(16));


const countEven = arr => arr.filter(a => a % 2 === 0).length;
console.log(countEven([1, 2, 3, 4, 5, 6]));


const getLengths = arr => arr.map(a => a.length > 0 ? a.length : 0 );
console.log(getLengths(["hi", "world", "JS"]));


const positiveOdd = arr => arr.filter(a => a > 0  && a % 2 !== 0);
console.log(positiveOdd([1, -3, 4, 7, -2, 5]));


const isDivisible = (a,b) => Number.isInteger(a/b) ? "disable" : "not disable";
console.log(isDivisible(10, 2));
console.log(isDivisible(7, 3));

const removeVowels = str => str.replace(/[aeiouAEIOU]/g, '');
console.log(removeVowels("hello world"));

const sumAboveAverage = arr =>
    arr.filter(n => n > arr.reduce((a, b) => a + b, 0) / arr.length)
        .reduce((a, b) => a + b, 0);
console.log(sumAboveAverage([1, 2, 3, 4, 5, 6]));
